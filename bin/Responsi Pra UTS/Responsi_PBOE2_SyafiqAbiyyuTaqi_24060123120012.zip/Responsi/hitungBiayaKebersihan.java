/************************************/
/* Nama file	: hitungBiayaKebersihan.java */
/* Deskripsi	: interface hitung biaya kebersihan */
/* Pembuat		: Syafiq Abiyyu Taqi / 24060123120012 */
/* Tanggal		: 27-03-2025 */
/***********************************/

public interface hitungBiayaKebersihan {
    public int biayaKebersihan();
}
